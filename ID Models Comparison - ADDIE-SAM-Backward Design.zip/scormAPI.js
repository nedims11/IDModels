/* Minimal SCORM 1.2 API wrapper
 * Locates the LMS-provided API object and exposes simple helpers.
 */
var SCORM = (function () {
  var api = null;
  var initialized = false;

  function findAPI(win) {
    var tries = 0;
    while (win && !win.API && win.parent && win.parent !== win && tries < 500) {
      tries++;
      win = win.parent;
    }
    return win ? win.API : null;
  }

  function getAPI() {
    if (api) return api;
    api = findAPI(window);
    if (!api && window.opener) api = findAPI(window.opener);
    return api;
  }

  function init() {
    var a = getAPI();
    if (!a) {
      console.warn("SCORM API not found - running outside an LMS.");
      return false;
    }
    if (initialized) return true;
    var ok = a.LMSInitialize("") === "true";
    initialized = ok;
    if (ok) {
      // Mark as incomplete on first launch if not already set
      var status = a.LMSGetValue("cmi.core.lesson_status");
      if (!status || status === "not attempted" || status === "") {
        a.LMSSetValue("cmi.core.lesson_status", "incomplete");
        a.LMSCommit("");
      }
    }
    return ok;
  }

  function setComplete() {
    var a = getAPI();
    if (!a || !initialized) return false;
    a.LMSSetValue("cmi.core.lesson_status", "completed");
    a.LMSCommit("");
    return true;
  }

  function getStatus() {
    var a = getAPI();
    if (!a || !initialized) return "unknown";
    return a.LMSGetValue("cmi.core.lesson_status");
  }

  function finish() {
    var a = getAPI();
    if (!a || !initialized) return false;
    a.LMSCommit("");
    a.LMSFinish("");
    initialized = false;
    return true;
  }

  // Auto-finish when the learner closes the tab/window
  window.addEventListener("beforeunload", function () {
    if (initialized) finish();
  });

  return {
    init: init,
    setComplete: setComplete,
    getStatus: getStatus,
    finish: finish
  };
})();
